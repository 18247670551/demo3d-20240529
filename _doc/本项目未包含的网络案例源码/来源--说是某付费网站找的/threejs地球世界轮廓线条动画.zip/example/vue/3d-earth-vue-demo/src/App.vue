<!--
 * @Author: ZY
 * @Date: 2022-01-06 09:07:13
 * @LastEditors: ZY
 * @LastEditTime: 2022-01-06 09:18:08
 * @FilePath: /3d-earth/example/vue/3d-earth-vue-demo/src/App.vue
 * @Description: 文件描述
-->
<template>
  <HelloWorld />
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    HelloWorld
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
