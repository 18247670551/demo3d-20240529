/*
 * @Author: ZY
 * @Date: 2021-12-31 10:56:41
 * @LastEditors: ZY
 * @LastEditTime: 2021-12-31 10:57:00
 * @FilePath: /3d-earth/typings.d.ts
 * @Description: 文件描述
 */
declare module "*.png";
declare module "*.less";
declare module "*.svg";
declare module "*.json";
