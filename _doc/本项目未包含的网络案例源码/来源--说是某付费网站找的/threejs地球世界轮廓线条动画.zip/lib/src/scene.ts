/*
 * @Author: ZY
 * @Date: 2021-12-30 10:14:34
 * @LastEditors: ZY
 * @LastEditTime: 2021-12-30 14:43:45
 * @FilePath: /3d-earth/lib/src/scene.ts
 * @Description: 场景文件
 */


import { Scene } from "three";

export const initScene = ()=>{
  let scene = new Scene();
  return scene
}

